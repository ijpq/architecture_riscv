
This is the README for bzip2, a block-sorting file compressor, version
1.0.  This version is fully compatible with the previous public
releases, bzip2-0.1pl2, bzip2-0.9.0 and bzip2-0.9.5.

bzip2-1.0 is distributed under a BSD-style license.  For details,
see the file LICENSE.

Complete documentation is available in Postscript form (manual.ps) or
html (manual_toc.html).  A plain-text version of the manual page is
available as bzip2.txt.  A statement about Y2K issues is now included
in the file Y2K_INFO.


HOW TO BUILD -- UNIX

Type `make'.  This builds the library libbz2.a and then the
programs bzip2 and bzip2recover.  Six self-tests are run.
If the self-tests complete ok, carry on to installation:

To install in /usr/bin, /usr/lib, /usr/man and /usr/include, type
   make install
To install somewhere else, eg, /xxx/yyy/{bin,lib,man,include}, type 
   make install PREFIX=/xxx/yyy
If you are (justifiably) paranoid and want to see what 'make install'
is going to do, you can first do
   make -n install                      or
   make -n install PREFIX=/xxx/yyy      respectively.
The -n instructs make to show the commands it would execute, but
not actually execute them.


HOW TO BUILD -- UNIX, shared library libbz2.so.

Do 'make -f Makefile-libbz2_so'.  This Makefile seems to work for
Linux-ELF (RedHat 5.2 on an x86 box), with gcc.  I make no claims
that it works for any other platform, though I suspect it probably
will work for most platforms employing both ELF and gcc.

bzip2-shared, a client of the shared library, is also build, but
not self-tested.  So I suggest you also build using the normal
Makefile, since that conducts a self-test.

Important note for people upgrading .so's from 0.9.0/0.9.5 to
version 1.0.  All the functions in the library have been renamed,
from (eg) bzCompress to BZ2_bzCompress, to avoid namespace pollution.
Unfortunately this means that the libbz2.so created by
Makefile-libbz2_so will not work with any program which used an
older version of the library.  Sorry.  I do encourage library
clients to make the effort to upgrade to use version 1.0, since
it is both faster and more robust than previous versions.


HOW TO BUILD -- Windows 95, NT, DOS, Mac, etc.

It's difficult for me to support compilation on all these platforms.
My approach is to collect binaries for these platforms, and put them
on the master web page (http://sourceware.cygnus.com/bzip2).  Look
there.  However (FWIW), bzip2-1.0 is very standard ANSI C and should
compile unmodified with MS Visual C.  For Win32, there is one
important caveat: in bzip2.c, you must set BZ_UNIX to 0 and
BZ_LCCWIN32 to 1 before building.  If you have difficulties building,
you might want to read README.COMPILATION.PROBLEMS.


VALIDATION

Correct operation, in the sense that a compressed file can always be
decompressed to reproduce the original, is obviously of paramount
importance.  To validate bzip2, I used a modified version of Mark
Nelson's churn program.  Churn is an automated test driver which
recursively traverses a directory structure, using bzip2 to compress
and then decompress each file it encounters, and checking that the
decompressed data is the same as the original.  There are more details
in Section 4 of the user guide.



Please read and be aware of the following:

WARNING:

   This program (attempts to) compress data by performing several
   non-trivial transformations on it.  Unless you are 100% familiar
   with *all* the algorithms contained herein, and with the
   consequences of modifying them, you should NOT meddle with the
   compression or decompression machinery.  Incorrect changes can and
   very likely *will* lead to disastrous loss of data.


DISCLAIMER:

   I TAKE NO RESPONSIBILITY FOR ANY LOSS OF DATA ARISING FROM THE
   USE OF THIS PROGRAM, HOWSOEVER CAUSED.

   Every compression of a file implies an assumption that the
   compressed file can be decompressed to reproduce the original.
   Great efforts in design, coding and testing have been made to
   ensure that this program works correctly.  However, the complexity
   of the algorithms, and, in particular, the presence of various
   special cases in the code which occur with very low but non-zero
   probability make it impossible to rule out the possibility of bugs
   remaining in the program.  DO NOT COMPRESS ANY DATA WITH THIS
   PROGRAM UNLESS YOU ARE PREPARED TO ACCEPT THE POSSIBILITY, HOWEVER
   SMALL, THAT THE DATA WILL NOT BE RECOVERABLE.

   That is not to say this program is inherently unreliable.  Indeed,
   I very much hope the opposite is true.  bzip2 has been carefully
   constructed and extensively tested.


PATENTS:

   To the best of my knowledge, bzip2 does not use any patented
   algorithms.  However, I do not have the resources available to
   carry out a full patent search.  Therefore I cannot give any
   guarantee of the above statement.

End of legalities.


WHAT'S NEW IN 0.9.0 (as compared to 0.1pl2) ?

   * Approx 10% faster compression, 30% faster decompression
   * -t (test mode) is a lot quicker
   * Can decompress concatenated compressed files
   * Programming interface, so programs can directly read/write .bz2 files
   * Less restrictive (BSD-style) licensing
   * Flag handling more compatible with GNU gzip
   * Much more documentation, i.e., a proper user manual
   * Hopefully, improved portability (at least of the library)

WHAT'S NEW IN 0.9.5 ?

   * Compression speed is much less sensitive to the input
     data than in previous versions.  Specifically, the very
     slow performance caused by repetitive data is fixed.
   * Many small improvements in file and flag handling.
   * A Y2K statement.

WHAT'S NEW IN 1.0

   See the CHANGES file.

I hope you find bzip2 useful.  Feel free to contact me at
   jseward@acm.org
if you have any suggestions or queries.  Many people mailed me with
comments, suggestions and patches after the releases of bzip-0.15,
bzip-0.21, bzip2-0.1pl2 and bzip2-0.9.0, and the changes in bzip2 are
largely a result of this feedback.  I thank you for your comments.

At least for the time being, bzip2's "home" is (or can be reached via)
http://www.muraroa.demon.co.uk.

Julian Seward
jseward@acm.org

Cambridge, UK
18   July 1996 (version 0.15)
25 August 1996 (version 0.21)
 7 August 1997 (bzip2, version 0.1)
29 August 1997 (bzip2, version 0.1pl2)
23 August 1998 (bzip2, version 0.9.0)
 8   June 1999 (bzip2, version 0.9.5)
 4   Sept 1999 (bzip2, version 0.9.5d)
 5    May 2000 (bzip2, version 1.0pre8)
