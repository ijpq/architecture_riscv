The SPEC version of SoPlex may be used only for benchmarking purposes.
